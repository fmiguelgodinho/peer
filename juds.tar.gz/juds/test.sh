#!/bin/bash
killall Python
rm JUDS_TEST*
make test
