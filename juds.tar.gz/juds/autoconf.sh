#!/bin/bash
autoconf -o ./configure configure.ac 

